from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from typing import Optional
from zoneinfo import ZoneInfo


MADRID_TZ = ZoneInfo("Europe/Madrid")


@dataclass(slots=True)
class TemporalInterpretation:
    status: str  # resolved | ambiguous_past_date | invalid | no_match
    title: Optional[str]
    candidate_iso: Optional[str]
    clarification_question: Optional[str]
    reason: Optional[str]
    extracted_day: Optional[int]
    extracted_month: Optional[int]
    extracted_hour: Optional[int]
    extracted_minute: Optional[int]


class TemporalInterpreter:
    MONTHS = {
        "enero": 1,
        "febrero": 2,
        "marzo": 3,
        "abril": 4,
        "mayo": 5,
        "junio": 6,
        "julio": 7,
        "agosto": 8,
        "septiembre": 9,
        "setiembre": 9,
        "octubre": 10,
        "noviembre": 11,
        "diciembre": 12,
    }

    def __init__(self, timezone_name: str = "Europe/Madrid"):
        self.tz = ZoneInfo(timezone_name)

    def interpret_appointment(
        self,
        text: str,
        now: Optional[datetime] = None,
    ) -> TemporalInterpretation:
        now = now or datetime.now(self.tz)
        raw = (text or "").strip().lower()

        title = self._infer_title(raw)
        day = self._extract_day(raw)
        month = self._extract_month(raw)
        hour, minute = self._extract_time(raw)

        if day is None or hour is None or minute is None:
            return TemporalInterpretation(
                status="no_match",
                title=title,
                candidate_iso=None,
                clarification_question=None,
                reason="missing_day_or_time",
                extracted_day=day,
                extracted_month=month,
                extracted_hour=hour,
                extracted_minute=minute,
            )

        next_month_explicit = any(
            phrase in raw
            for phrase in [
                "mes que viene",
                "el mes que viene",
                "próximo mes",
                "proximo mes",
                "mes siguiente",
            ]
        )

        this_month_explicit = "este mes" in raw

        # Caso 1: mes explícito por nombre ("abril", "mayo"...)
        if month is not None:
            candidate = self._safe_build(now.year, month, day, hour, minute)
            if candidate is None:
                return self._invalid(title, day, month, hour, minute, "invalid_explicit_month_date")

            # Si ese mes/día ya ha pasado este año, asumimos siguiente año
            if candidate < now:
                candidate = self._safe_build(now.year + 1, month, day, hour, minute)
                if candidate is None:
                    return self._invalid(title, day, month, hour, minute, "invalid_explicit_month_next_year_date")

            return TemporalInterpretation(
                status="resolved",
                title=title,
                candidate_iso=candidate.isoformat(),
                clarification_question=None,
                reason="explicit_month",
                extracted_day=day,
                extracted_month=month,
                extracted_hour=hour,
                extracted_minute=minute,
            )

        # Caso 2: "mes que viene"
        if next_month_explicit:
            year, next_month = self._next_month(now.year, now.month)
            candidate = self._safe_build(year, next_month, day, hour, minute)
            if candidate is None:
                return self._invalid(title, day, next_month, hour, minute, "invalid_next_month_date")

            return TemporalInterpretation(
                status="resolved",
                title=title,
                candidate_iso=candidate.isoformat(),
                clarification_question=None,
                reason="next_month_explicit",
                extracted_day=day,
                extracted_month=next_month,
                extracted_hour=hour,
                extracted_minute=minute,
            )

        # Caso 3: sin mes explícito -> mes actual
        candidate = self._safe_build(now.year, now.month, day, hour, minute)
        if candidate is None:
            return self._invalid(title, day, now.month, hour, minute, "invalid_current_month_date")

        if candidate < now:
            question = (
                f"El {day} de este mes ya ha pasado. "
                f"¿Te refieres al {day} del mes que viene a las {hour:02d}:{minute:02d}?"
            )

            return TemporalInterpretation(
                status="ambiguous_past_date",
                title=title,
                candidate_iso=candidate.isoformat(),
                clarification_question=question,
                reason="explicit_this_month_in_past" if this_month_explicit else "implicit_month_in_past",
                extracted_day=day,
                extracted_month=now.month,
                extracted_hour=hour,
                extracted_minute=minute,
            )

        return TemporalInterpretation(
            status="resolved",
            title=title,
            candidate_iso=candidate.isoformat(),
            clarification_question=None,
            reason="current_month_future",
            extracted_day=day,
            extracted_month=now.month,
            extracted_hour=hour,
            extracted_minute=minute,
        )

    def resolve_clarification(
        self,
        reply_text: str,
        draft: dict,
        now: Optional[datetime] = None,
    ) -> TemporalInterpretation:
        now = now or datetime.now(self.tz)
        raw = (reply_text or "").strip().lower()

        draft_day = draft.get("day")
        draft_hour = draft.get("hour")
        draft_minute = draft.get("minute")
        draft_title = draft.get("title") or "Cita"

        # 1) Si el usuario responde con una fecha nueva completa, se reinterpreta
        fresh = self.interpret_appointment(reply_text, now=now)
        if fresh.status in {"resolved", "ambiguous_past_date", "invalid"}:
            return fresh

        # 2) Si no, intentamos aclaración breve del draft existente
        if draft_day is None or draft_hour is None or draft_minute is None:
            return TemporalInterpretation(
                status="invalid",
                title=draft_title,
                candidate_iso=None,
                clarification_question="No me ha quedado clara la fecha. ¿Me dices la fecha completa?",
                reason="draft_incomplete",
                extracted_day=draft_day,
                extracted_month=draft.get("month"),
                extracted_hour=draft_hour,
                extracted_minute=draft_minute,
            )

        positive = any(x in raw for x in ["sí", "si", "correcto", "exacto", "eso", "yes"])
        next_month = any(
            x in raw
            for x in [
                "mes que viene",
                "el mes que viene",
                "próximo mes",
                "proximo mes",
                "mes siguiente",
            ]
        )

        if positive or next_month:
            year, month = self._next_month(now.year, now.month)
            candidate = self._safe_build(year, month, int(draft_day), int(draft_hour), int(draft_minute))
            if candidate is None:
                return self._invalid(
                    draft_title,
                    int(draft_day),
                    month,
                    int(draft_hour),
                    int(draft_minute),
                    "invalid_next_month_date",
                )

            return TemporalInterpretation(
                status="resolved",
                title=draft_title,
                candidate_iso=candidate.isoformat(),
                clarification_question=None,
                reason="clarification_confirmed_next_month",
                extracted_day=int(draft_day),
                extracted_month=month,
                extracted_hour=int(draft_hour),
                extracted_minute=int(draft_minute),
            )

        return TemporalInterpretation(
            status="invalid",
            title=draft_title,
            candidate_iso=None,
            clarification_question="No me ha quedado clara la fecha. ¿Me dices la fecha completa, por ejemplo 'el 23 de abril a las 5'?",
            reason="clarification_not_understood",
            extracted_day=int(draft_day) if draft_day is not None else None,
            extracted_month=draft.get("month"),
            extracted_hour=int(draft_hour) if draft_hour is not None else None,
            extracted_minute=int(draft_minute) if draft_minute is not None else None,
        )

    def _infer_title(self, text: str) -> str:
        if "psicóloga" in text or "psicologa" in text:
            return "Psicóloga"
        if "médico" in text or "medico" in text:
            return "Médico"
        if "dentista" in text:
            return "Dentista"
        if "cita" in text:
            return "Cita"
        return "Cita"

    def _extract_day(self, text: str) -> Optional[int]:
        patterns = [
            r"\bel\s+(\d{1,2})\b",
            r"\bd[ií]a\s+(\d{1,2})\b",
        ]
        for pattern in patterns:
            m = re.search(pattern, text)
            if m:
                day = int(m.group(1))
                if 1 <= day <= 31:
                    return day
        return None

    def _extract_month(self, text: str) -> Optional[int]:
        for name, value in self.MONTHS.items():
            if re.search(rf"\b{name}\b", text):
                return value
        return None

    def _extract_time(self, text: str) -> tuple[Optional[int], Optional[int]]:
        # 15:30 o 15.30
        m = re.search(r"\b(\d{1,2})[:.](\d{2})\b", text)
        if m:
            hour = int(m.group(1))
            minute = int(m.group(2))
            if 0 <= hour <= 23 and 0 <= minute <= 59:
                return hour, minute

        # "a las 3 y media"
        m = re.search(r"\ba las\s+(\d{1,2})\s+y\s+media\b", text)
        if m:
            hour = int(m.group(1))
            if 0 <= hour <= 23:
                return hour, 30
            
        m = re.search(r"\ba las\s+(\d{1,2})\s+y\s+(\d{1,2})\b", text)
        if m:
            hour = int(m.group(1))
            minute = int(m.group(2))
            if 0 <= hour <= 23 and 0 <= minute <= 59:
                return hour, minute
            
        # "a las 3"
        m = re.search(r"\ba las\s+(\d{1,2})\b", text)
        if m:
            hour = int(m.group(1))
            if 0 <= hour <= 23:
                return hour, 0

        return None, None

    def _safe_build(
        self,
        year: int,
        month: int,
        day: int,
        hour: int,
        minute: int,
    ) -> Optional[datetime]:
        try:
            return datetime(year, month, day, hour, minute, tzinfo=self.tz)
        except ValueError:
            return None

    def _next_month(self, year: int, month: int) -> tuple[int, int]:
        if month == 12:
            return year + 1, 1
        return year, month + 1

    def _invalid(
        self,
        title: Optional[str],
        day: Optional[int],
        month: Optional[int],
        hour: Optional[int],
        minute: Optional[int],
        reason: str,
    ) -> TemporalInterpretation:
        return TemporalInterpretation(
            status="invalid",
            title=title,
            candidate_iso=None,
            clarification_question="La fecha no me cuadra. ¿Me dices la fecha completa?",
            reason=reason,
            extracted_day=day,
            extracted_month=month,
            extracted_hour=hour,
            extracted_minute=minute,
        )