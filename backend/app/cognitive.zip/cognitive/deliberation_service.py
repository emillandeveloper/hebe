# backend/app/cognitive/deliberation_service.py
from __future__ import annotations

from datetime import datetime
from zoneinfo import ZoneInfo

from app.cognitive.context_builder import BuiltContext
from app.cognitive.models import PlanStep, Plan, DeliberationResult
from app.cognitive.temporal_interpreter import TemporalInterpreter


class DeliberationService:
    def __init__(self, intent_model, reasoning_model):
        self.intent_model = intent_model
        self.reasoning_model = reasoning_model
        self.temporal = TemporalInterpreter("Europe/Madrid")

    def deliberate(self, context: BuiltContext) -> DeliberationResult:
        if context.internal_event:
            return self._handle_internal_event(context)

        if context.input_text:
            return self._handle_user_input(context)

        return DeliberationResult(plan=Plan(steps=[]))

    def _handle_internal_event(self, context: BuiltContext) -> DeliberationResult:
        event = context.internal_event

        if event.event_type == "reminder_due":
            return DeliberationResult(
                plan=Plan(
                    steps=[
                        PlanStep(
                            type="reply",
                            data={
                                "mode": "reminder",
                                "payload": event.payload,
                            },
                        )
                    ],
                    reasoning="Reminder due -> notify user",
                )
            )

        return DeliberationResult(plan=Plan(steps=[]))

    def _handle_user_input(self, context: BuiltContext) -> DeliberationResult:
        text = (context.input_text or "").strip().lower()

        pending = context.state_snapshot.get("pending_clarification")
        if pending and pending.get("kind") == "appointment_datetime":
            return self._resolve_pending_appointment(context, pending)

        if self._looks_like_appointment(text):
            return self._plan_appointment(context)

        app_name = self._extract_open_app_target(text)
        if app_name:
            return self._plan_open_app(app_name)

        return self._plan_with_llm(context)

    def _handle_appointment_interpretation(self, context: BuiltContext):
        now = datetime.now(ZoneInfo("Europe/Madrid"))
        interp = self.temporal.interpret_appointment(context.input_text or "", now=now)
        return interp

    def _plan_appointment(self, context: BuiltContext) -> DeliberationResult:
        interp = self._handle_appointment_interpretation(context)

        if interp.status == "resolved":
            title = interp.title or "Cita"
            return DeliberationResult(
                plan=Plan(
                    steps=[
                        PlanStep(
                            type="memory",
                            data={
                                "kind": "appointment",
                                "title": title,
                                "due_at": interp.candidate_iso,
                                "source_text": context.input_text,
                                "payload": {
                                    "title": title,
                                    "due_at": interp.candidate_iso,
                                },
                            },
                        ),
                        PlanStep(
                            type="reminder",
                            data={
                                "title": title,
                                "due_at": interp.candidate_iso,
                                "kind": "appointment",
                                "message": f"Te recuerdo: {title}",
                                "payload": {
                                    "title": title,
                                    "due_at": interp.candidate_iso,
                                },
                            },
                        ),
                        PlanStep(
                            type="reply",
                            data={"mode": "confirm_appointment"},
                        ),
                    ],
                    reasoning=f"Resolved appointment datetime: {interp.reason}",
                )
            )

        if interp.status in {"ambiguous_past_date", "invalid"}:
            draft = {
                "title": interp.title or "Cita",
                "day": interp.extracted_day,
                "month": interp.extracted_month,
                "hour": interp.extracted_hour,
                "minute": interp.extracted_minute,
                "source_text": context.input_text,
                "reason": interp.reason,
            }

            return DeliberationResult(
                plan=Plan(
                    steps=[
                        PlanStep(
                            type="reply",
                            data={
                                "mode": "clarify_appointment_datetime",
                                "question": interp.clarification_question or "¿Qué fecha exacta quieres decir?",
                                "draft": draft,
                            },
                        )
                    ],
                    reasoning=f"Appointment clarification needed: {interp.reason}",
                )
            )

        return DeliberationResult(
            plan=Plan(
                steps=[
                    PlanStep(
                        type="reply",
                        data={
                            "mode": "clarify_appointment_datetime",
                            "question": "No me ha quedado clara la fecha. ¿Me dices el día y el mes?",
                            "draft": {
                                "title": "Cita",
                                "source_text": context.input_text,
                                "reason": "no_match",
                            },
                        },
                    )
                ],
                reasoning="Appointment parsing failed",
            )
        )

    def _resolve_pending_appointment(self, context: BuiltContext, pending: dict) -> DeliberationResult:
        now = datetime.now(ZoneInfo("Europe/Madrid"))

        # 1) Intentar resolver como aclaración breve del draft pendiente
        interp = self.temporal.resolve_clarification(
            reply_text=context.input_text or "",
            draft=pending.get("draft", {}),
            now=now,
        )

        if interp.status == "resolved":
            title = interp.title or "Cita"
            return DeliberationResult(
                plan=Plan(
                    steps=[
                        PlanStep(
                            type="memory",
                            data={
                                "kind": "appointment",
                                "title": title,
                                "due_at": interp.candidate_iso,
                                "source_text": pending.get("draft", {}).get("source_text"),
                                "payload": {
                                    "title": title,
                                    "due_at": interp.candidate_iso,
                                },
                            },
                        ),
                        PlanStep(
                            type="reminder",
                            data={
                                "title": title,
                                "due_at": interp.candidate_iso,
                                "kind": "appointment",
                                "message": f"Te recuerdo: {title}",
                                "payload": {
                                    "title": title,
                                    "due_at": interp.candidate_iso,
                                },
                            },
                        ),
                        PlanStep(
                            type="reply",
                            data={"mode": "confirm_appointment"},
                        ),
                    ],
                    reasoning=f"Pending appointment clarified: {interp.reason}",
                )
            )

        # 2) Si no ha entendido la aclaración breve, intentar tratar esta frase
        #    como una nueva fecha/cita completa
        fresh_interp = self.temporal.interpret_appointment(
            context.input_text or "",
            now=now,
        )

        if fresh_interp.status == "resolved":
            title = fresh_interp.title or pending.get("draft", {}).get("title") or "Cita"
            return DeliberationResult(
                plan=Plan(
                    steps=[
                        PlanStep(
                            type="memory",
                            data={
                                "kind": "appointment",
                                "title": title,
                                "due_at": fresh_interp.candidate_iso,
                                "source_text": context.input_text,
                                "payload": {
                                    "title": title,
                                    "due_at": fresh_interp.candidate_iso,
                                },
                            },
                        ),
                        PlanStep(
                            type="reminder",
                            data={
                                "title": title,
                                "due_at": fresh_interp.candidate_iso,
                                "kind": "appointment",
                                "message": f"Te recuerdo: {title}",
                                "payload": {
                                    "title": title,
                                    "due_at": fresh_interp.candidate_iso,
                                },
                            },
                        ),
                        PlanStep(
                            type="reply",
                            data={"mode": "confirm_appointment"},
                        ),
                    ],
                    reasoning=f"Pending appointment replaced by fresh resolved input: {fresh_interp.reason}",
                )
            )

        if fresh_interp.status in {"ambiguous_past_date", "invalid"}:
            draft = {
                "title": fresh_interp.title or pending.get("draft", {}).get("title") or "Cita",
                "day": fresh_interp.extracted_day,
                "month": fresh_interp.extracted_month,
                "hour": fresh_interp.extracted_hour,
                "minute": fresh_interp.extracted_minute,
                "source_text": context.input_text,
                "reason": fresh_interp.reason,
            }

            return DeliberationResult(
                plan=Plan(
                    steps=[
                        PlanStep(
                            type="reply",
                            data={
                                "mode": "clarify_appointment_datetime",
                                "question": fresh_interp.clarification_question or "No me ha quedado clara la fecha. ¿Qué mes es exactamente?",
                                "draft": draft,
                            },
                        )
                    ],
                    reasoning=f"Pending appointment replaced by fresh ambiguous input: {fresh_interp.reason}",
                )
            )

        # 3) Si no entiende ni la aclaración ni una nueva fecha completa
        return DeliberationResult(
            plan=Plan(
                steps=[
                    PlanStep(
                        type="reply",
                        data={
                            "mode": "clarify_appointment_datetime",
                            "question": "No me ha quedado claro. ¿Me dices la fecha completa, por ejemplo 'el 23 de abril a las 5'?",
                            "draft": pending.get("draft", {}),
                        },
                    )
                ],
                reasoning=f"Pending appointment still ambiguous: {interp.reason}",
            )
        )

    def _looks_like_appointment(self, text: str) -> bool:
        keywords = ["psicóloga", "psicologa", "médico", "medico", "dentista", "cita", "hora"]
        return any(k in text for k in keywords)

    def _extract_open_app_target(self, text: str) -> str | None:
        prefixes = ["abre ", "open "]
        for prefix in prefixes:
            if text.startswith(prefix):
                candidate = text[len(prefix):].strip()
                if candidate:
                    return candidate
        return None

    def _plan_open_app(self, app_name: str) -> DeliberationResult:
        return DeliberationResult(
            plan=Plan(
                steps=[
                    PlanStep(
                        type="action",
                        data={
                            "name": "open_app",
                            "params": {
                                "app_name": app_name,
                            },
                        },
                    ),
                    PlanStep(
                        type="reply",
                        data={"mode": "confirm_action"},
                    ),
                ],
                reasoning=f"User requested open_app for {app_name}",
            )
        )

    def _plan_with_llm(self, context: BuiltContext) -> DeliberationResult:
        return DeliberationResult(
            plan=Plan(
                steps=[
                    PlanStep(
                        type="reply",
                        data={"mode": "chat"},
                    )
                ],
                reasoning="Fallback chat",
            )
        )